const authToken = require("./auth_token");

exports.handler = async (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  
  let token = event.headers.hasOwnProperty("authorization")
    ? event.headers["authorization"]
    : event.headers["Authorization"];
  
  const results = await authToken.auth(event.headers);
  const response = {
    statusCode: !results.hasOwnProperty("error") ? 200 : 400,
    headers: {
      "Access-Control-Allow-Origin": "*",
    },
    body: JSON.stringify(results)
  };
  
  callback(null, response);
};
