
const AWS = require('aws-sdk'),
  JWT = require("jsonwebtoken"),
  secretsClient = new AWS.SecretsManager({
    region: process.env.AWS_REGION
  });

const getSecret = (secretId) => {
  return new Promise((resolve, reject) =>
    secretsClient.getSecretValue({ SecretId: secretId }, (err, data) => {
      let secret, decodedBinarySecret;

      if (err || data == null) {
        reject(err);
      } else {
        if ('SecretString' in data) {
          secret = data.SecretString;
        } else {
          let buff = new Buffer(data.SecretBinary, 'base64');
          decodedBinarySecret = buff.toString('ascii');
        }

        resolve(secret
          ? JSON.parse(secret)
          : JSON.parse(decodedBinarySecret));
      }
    })
  );
}

const auth = async (name, token) => {  
  return new Promise(async (resolve, reject) => {
   
  });
};

module.exports = {
  auth
}